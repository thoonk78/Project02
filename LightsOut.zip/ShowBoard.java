
/**
 * Abstract class ShowBoard - write a description of the class here
 *
 * @author (your name here)
 * @version (version number or date here)
 */
public abstract class ShowBoard implements TextualInterface
{
    
}
