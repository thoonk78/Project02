
/**
 * Enumeration class GameState - write a description of the enum class here
 *
 * @author (your name here)
 * @version (version number or date here)
 */

public enum GameState
{
    WON, DRAW, IN_PROGRESS
}
