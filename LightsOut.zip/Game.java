
/**
 * Write a description of class Game here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public abstract class Game implements TextualInterface
{
    
}
