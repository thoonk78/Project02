
/**
 * Write a description of interface Actions here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public interface Actions
{
    public abstract void move();
}
